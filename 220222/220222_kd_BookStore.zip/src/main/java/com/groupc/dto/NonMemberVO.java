package com.groupc.dto;

public class NonMemberVO {
	private String phone;
	private String name;
	private String email;
	private String od_pass;
	private String zip_num;
	private String address;
	public String getZip_num() {
		return zip_num;
	}
	public void setZip_num(String zip_num) {
		this.zip_num = zip_num;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOd_pass() {
		return od_pass;
	}
	public void setOd_pass(String od_pass) {
		this.od_pass = od_pass;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
