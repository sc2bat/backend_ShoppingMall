

function writeReview(){
	document.pdfrm2.action = "bs.do?cmd=writeReview";
	document.pdfrm2.submit();
	
}